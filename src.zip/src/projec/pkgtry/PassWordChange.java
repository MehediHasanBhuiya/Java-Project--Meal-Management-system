
package projec.pkgtry;

import java.io.File;
import java.io.FileWriter;
import java.util.Scanner;
import javax.swing.JOptionPane;


public class PassWordChange extends javax.swing.JFrame {

    loging obj = new loging();
    public PassWordChange() {
        initComponents();
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLayeredPane1 = new javax.swing.JLayeredPane();
        jLabel1 = new javax.swing.JLabel();
        tbxConfirmPassword = new javax.swing.JTextField();
        tbNewPassword = new javax.swing.JPasswordField();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        lpassWord = new javax.swing.JLabel();
        lbxUserName = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        MenuitemMainMenu = new javax.swing.JMenuItem();
        jMenuItem1 = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMaximizedBounds(new java.awt.Rectangle(1000, 722, 722, 722));
        setMaximumSize(new java.awt.Dimension(1000, 722));
        setPreferredSize(new java.awt.Dimension(1000, 722));

        jLayeredPane1.setBackground(new java.awt.Color(2, 1, 1));
        jLayeredPane1.setForeground(new java.awt.Color(51, 51, 51));
        jLayeredPane1.setMinimumSize(new java.awt.Dimension(1000, 650));

        jLabel1.setBackground(new java.awt.Color(255, 102, 102));
        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 36)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Password change ");
        jLabel1.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jLayeredPane1.add(jLabel1);
        jLabel1.setBounds(232, 138, 498, 89);
        jLayeredPane1.add(tbxConfirmPassword);
        tbxConfirmPassword.setBounds(404, 354, 124, 31);
        jLayeredPane1.add(tbNewPassword);
        tbNewPassword.setBounds(404, 284, 124, 31);

        jButton1.setText("Change");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jLayeredPane1.add(jButton1);
        jButton1.setBounds(604, 284, 112, 32);

        jButton2.setText("Clear");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jLayeredPane1.add(jButton2);
        jButton2.setBounds(604, 353, 112, 32);

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 153, 153));
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("Confirm Password");
        jLayeredPane1.add(jLabel2);
        jLabel2.setBounds(204, 353, 150, 32);

        lpassWord.setBackground(new java.awt.Color(0, 0, 0));
        lpassWord.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        lpassWord.setForeground(new java.awt.Color(255, 153, 153));
        lpassWord.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lpassWord.setText("New Password");
        jLayeredPane1.add(lpassWord);
        lpassWord.setBounds(214, 284, 124, 40);

        lbxUserName.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        lbxUserName.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLayeredPane1.add(lbxUserName);
        lbxUserName.setBounds(746, 23, 241, 54);

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/projec/pkgtry/background.jpg"))); // NOI18N
        jLayeredPane1.add(jLabel4);
        jLabel4.setBounds(0, 0, 1010, 700);

        jMenu1.setText("Menu");

        MenuitemMainMenu.setText("Main Menu");
        MenuitemMainMenu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MenuitemMainMenuActionPerformed(evt);
            }
        });
        jMenu1.add(MenuitemMainMenu);

        jMenuItem1.setText("Exit");
        jMenuItem1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem1ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem1);

        jMenuBar1.add(jMenu1);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLayeredPane1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLayeredPane1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed

        showUser();
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        
        System.out.println(obj.user);
        showUser();

        String fUser ;
        String oldPassWord;
        String main =" ";
        if (tbNewPassword.getText().equalsIgnoreCase("") || tbNewPassword.getText().equalsIgnoreCase(" ")){
            JOptionPane.showMessageDialog(null, "Sorry No Input Found");

        }
        else if (tbNewPassword.getText().equalsIgnoreCase(tbxConfirmPassword.getText())){

            try {
                File f = new File("loging.txt");
                Scanner scan = new Scanner(f);
                while(scan.hasNext()){
                    fUser = scan.next();
                    oldPassWord = scan.next();
                    if (obj.user.equalsIgnoreCase(fUser)){
                        oldPassWord = tbxConfirmPassword.getText();
                    }
                    main += fUser+" "+oldPassWord+" ";
                }

                FileWriter fw = new FileWriter(f);
                fw.write(main);
                fw.close();

                JOptionPane.showMessageDialog(null, "Hello "+obj.user+" , Your PassWord SuccessFully Change");

            }
            catch (Exception e) {
                JOptionPane.showMessageDialog(null, "Sorry Something Wrong");
            }
        }

        else {
            JOptionPane.showMessageDialog(null, "Password Not Match");
        }

        tbNewPassword.setText("");
        tbxConfirmPassword.setText("");
    }//GEN-LAST:event_jButton1ActionPerformed

    private void MenuitemMainMenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MenuitemMainMenuActionPerformed
        Menu objMain = new Menu();
        objMain.setVisible(true);
        dispose();
    }//GEN-LAST:event_MenuitemMainMenuActionPerformed

    private void jMenuItem1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem1ActionPerformed
        System.exit(0);
    }//GEN-LAST:event_jMenuItem1ActionPerformed

    public void showUser(){
        lbxUserName.setText(obj.user);
       lbxUserName.setText(obj.user);
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(PassWordChange.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(PassWordChange.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(PassWordChange.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(PassWordChange.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new PassWordChange().setVisible(true);
                
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenuItem MenuitemMainMenu;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLayeredPane jLayeredPane1;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JLabel lbxUserName;
    private javax.swing.JLabel lpassWord;
    private javax.swing.JPasswordField tbNewPassword;
    private javax.swing.JTextField tbxConfirmPassword;
    // End of variables declaration//GEN-END:variables
}
