
package projec.pkgtry;

//import com.sun.xml.internal.ws.api.streaming.XMLStreamWriterFactory;
import java.io.File;
import java.util.Scanner;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author p
 */
public class WholeDetails extends javax.swing.JFrame {
    
    JFileChooser fc;
    File dir;
    DefaultTableModel model;

    //String Name;
    int rc, totalRecievedTaka, totalCost;
    MealEntry me = new MealEntry();
    Menu m=new Menu();
    
    public WholeDetails() {
        initComponents();
        
        model = new DefaultTableModel();
        tbl.setModel(model);
        model.addColumn("   Member's name");
        model.addColumn("   Total Meal");
        model.addColumn("   Spent");
        model.addColumn("   Collect");
        model.addColumn("   Pay");
        
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        tbl = new javax.swing.JTable();
        jPanel3 = new javax.swing.JPanel();
        btnClear = new javax.swing.JButton();
        btnDisplay = new javax.swing.JButton();
        btnBack = new javax.swing.JButton();
        btnExit = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        tbxTotalBalance = new javax.swing.JTextField();
        tbxRemainingCash = new javax.swing.JTextField();
        tbxTotalShopping = new javax.swing.JTextField();
        tbxMealRate = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "Member's ID", "Member' name", "Total Meal", "Spent", "Collect", "Pay"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMaximumSize(new java.awt.Dimension(950, 651));
        setMinimumSize(new java.awt.Dimension(950, 651));
        setPreferredSize(new java.awt.Dimension(950, 651));
        getContentPane().setLayout(null);

        jPanel2.setBackground(new java.awt.Color(51, 102, 0));

        jScrollPane2.setBackground(new java.awt.Color(255, 153, 153));

        tbl.setBackground(jLabel6.getForeground());
        tbl.setForeground(new java.awt.Color(204, 204, 204));
        tbl.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "Member' Name", "Total Meal", "Spent", "Collect", "Pay"
            }
        ));
        tbl.setSelectionForeground(new java.awt.Color(0, 153, 153));
        jScrollPane2.setViewportView(tbl);

        jPanel3.setBackground(new java.awt.Color(51, 102, 0));

        btnClear.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btnClear.setForeground(new java.awt.Color(102, 102, 255));
        btnClear.setText("Clear");
        btnClear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnClearActionPerformed(evt);
            }
        });

        btnDisplay.setBackground(java.awt.SystemColor.window);
        btnDisplay.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btnDisplay.setForeground(new java.awt.Color(102, 102, 255));
        btnDisplay.setText("Display");
        btnDisplay.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDisplayActionPerformed(evt);
            }
        });

        btnBack.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btnBack.setForeground(new java.awt.Color(51, 102, 255));
        btnBack.setText("Main menu");
        btnBack.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBackActionPerformed(evt);
            }
        });

        btnExit.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btnExit.setForeground(new java.awt.Color(51, 51, 255));
        btnExit.setText("Exit");
        btnExit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnExitActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(41, 41, 41)
                .addComponent(btnDisplay)
                .addGap(68, 68, 68)
                .addComponent(btnClear)
                .addGap(73, 73, 73)
                .addComponent(btnBack)
                .addGap(80, 80, 80)
                .addComponent(btnExit, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(13, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnClear)
                    .addComponent(btnDisplay)
                    .addComponent(btnBack)
                    .addComponent(btnExit))
                .addContainerGap(19, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 946, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(98, 98, 98)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap(25, Short.MAX_VALUE)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 138, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        getContentPane().add(jPanel2);
        jPanel2.setBounds(0, 337, 940, 252);

        jPanel1.setBackground(jLabel6.getForeground());

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 153, 51));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Total Balance Of Members");
        jLabel1.setBorder(new javax.swing.border.MatteBorder(null));

        jLabel2.setBackground(new java.awt.Color(51, 51, 255));
        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 153, 0));
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("Remaining Cash");
        jLabel2.setBorder(new javax.swing.border.MatteBorder(null));

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(0, 153, 0));
        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel3.setText("Total Shopping");
        jLabel3.setBorder(new javax.swing.border.MatteBorder(null));

        jLabel4.setBackground(new java.awt.Color(0, 0, 51));
        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(0, 153, 0));
        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel4.setText("Per Meal Rate");
        jLabel4.setBorder(new javax.swing.border.MatteBorder(null));
        jLabel4.setDebugGraphicsOptions(javax.swing.DebugGraphics.LOG_OPTION);

        tbxTotalBalance.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        tbxTotalBalance.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        tbxTotalBalance.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tbxTotalBalanceActionPerformed(evt);
            }
        });

        tbxRemainingCash.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        tbxRemainingCash.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        tbxRemainingCash.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tbxRemainingCashActionPerformed(evt);
            }
        });

        tbxTotalShopping.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        tbxTotalShopping.setHorizontalAlignment(javax.swing.JTextField.CENTER);

        tbxMealRate.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        tbxMealRate.setHorizontalAlignment(javax.swing.JTextField.CENTER);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap(133, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, 185, Short.MAX_VALUE)
                    .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(78, 78, 78)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(tbxTotalBalance, javax.swing.GroupLayout.DEFAULT_SIZE, 125, Short.MAX_VALUE)
                    .addComponent(tbxTotalShopping)
                    .addComponent(tbxRemainingCash)
                    .addComponent(tbxMealRate, javax.swing.GroupLayout.Alignment.TRAILING))
                .addGap(90, 90, 90))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(11, 11, 11)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(tbxTotalBalance, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(tbxRemainingCash, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(tbxTotalShopping, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(tbxMealRate, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel1);
        jPanel1.setBounds(115, 157, 611, 174);

        jLabel5.setBackground(new java.awt.Color(153, 153, 153));
        jLabel5.setFont(new java.awt.Font("Tahoma", 0, 48)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel5.setText("WHOLE DETAILS QUERY");
        getContentPane().add(jLabel5);
        jLabel5.setBounds(35, 6, 791, 140);

        jLabel6.setBackground(new java.awt.Color(255, 153, 153));
        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/projec/pkgtry/green bamboo powerpoint desain.jpg"))); // NOI18N
        getContentPane().add(jLabel6);
        jLabel6.setBounds(-10, 0, 960, 590);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    public void clearDisplay(){
        tbxTotalBalance.setText("");
        tbxRemainingCash.setText("");
        tbxTotalShopping.setText("");
        tbxMealRate.setText("");
        clear();
    }
    
    
    
    private void btnClearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnClearActionPerformed
             
        clearDisplay();
        
    }//GEN-LAST:event_btnClearActionPerformed

    private void tbxRemainingCashActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tbxRemainingCashActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tbxRemainingCashActionPerformed

    private void tbxTotalBalanceActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tbxTotalBalanceActionPerformed
        // TODO add your handling code here:


    }//GEN-LAST:event_tbxTotalBalanceActionPerformed

    private void btnDisplayActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDisplayActionPerformed
        // TODO add your handling code here:
        
        clearDisplay();

        
        String num = "";
        try {
            File f = new File("TotalRecievedTaka.txt");
            Scanner input = new Scanner(f);
            
            while (input.hasNext()) {
                num = input.nextLine();
            }
        } catch (Exception ex) {
            System.out.println("File not Found");
        }
        tbxTotalBalance.setText(num);

        //remaining cash calculation
        String num1 = " ";
        //int rc, a, b;

        try {
            File f1 = new File("TotalRecievedTaka.txt");
            Scanner input1 = new Scanner(f1);
            
            num1 = input1.nextLine();
            

            File f2 = new File("TotalCost.txt");
            Scanner input2 = new Scanner(f2);
            String num2 = "";
            
            num2 = input2.next();
            totalRecievedTaka = Integer.parseInt(num1);
            totalCost = Integer.parseInt(num2);
            
            rc = totalRecievedTaka - totalCost;
            //System.out.println(totalCost);
            tbxRemainingCash.setText(String.valueOf(rc));
            
        } catch (Exception ex) {
            System.out.println("TotalCost File not Found");
        }
        //total shopping

        try {
            File f3 = new File("TotalCost.txt");
            Scanner input3 = new Scanner(f3);
            String num3 = "";
            while (input3.hasNext()) {
                num3 += input3.nextLine() + "\n";
                tbxTotalShopping.setText(String.valueOf(num3));
            }
        } catch (Exception ex) {
            System.out.println("File not Found");
        }

        //meal rate = mr
        int mr = 0;
        try {
            File f4 = new File("TotalMeal.txt");
            Scanner input4 = new Scanner(f4);
            String num4 = "";
            
            num4 = input4.nextLine();
            int n4 = Integer.parseInt(num4);
            mr = totalCost / n4;
            tbxMealRate.setText(String.valueOf(mr));
            
        } catch (Exception ex) {
            System.out.println("TotalMeal File not Found");
        }
        
        String memName, Name[] = {"Sheiblu", "Mehedi", "Maruf", "Shemul", "Sourove"};
        
        for (int i = 0; i < Name.length; i++) {
            int memMeal, perPersoMeal = 0, mainPerPersonMeal = 0;
            
            try {
                
                File f = new File("MealPerPerson.txt");
                Scanner inputfile = new Scanner(f);
                
                while (inputfile.hasNext()) {
                    
                    memName = inputfile.next();
                    memMeal = inputfile.nextInt();
                    if (memName.equalsIgnoreCase(Name[i])) {
                        mainPerPersonMeal = memMeal;
                        break;
                    }
                    
                }
                
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "Sorry something Wrong");
            }
            int spent = mainPerPersonMeal * mr;

            // per person collected money
            int mainPerPersonCost = 0, memCost;
            String pay = "";
            
            try {
                
                File f = new File("TotalPeopleGiveCost.txt");
                Scanner inputfile = new Scanner(f);
                
                while (inputfile.hasNext()) {
                    
                    memName = inputfile.next();
                    memCost = inputfile.nextInt();
                    if (memName.equalsIgnoreCase(Name[i])) {
                        mainPerPersonCost = memCost;
                        
                    }
                    if (spent > mainPerPersonCost) {
                        pay = "Pay Able";
                    } else {
                        pay = "No Pay";
                    }
                    
                }
                
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "Sorry something Wrong rn");
            }
            
            model.addRow(new Object[]{Name[i], mainPerPersonMeal, spent, mainPerPersonCost, pay});
            
        }
       
        

    }//GEN-LAST:event_btnDisplayActionPerformed

    private void btnExitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnExitActionPerformed
        // TODO add your handling code here:
        System.exit(0);
    }//GEN-LAST:event_btnExitActionPerformed

    private void btnBackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBackActionPerformed
        // TODO add your handling code here:
        m.setVisible(true);
        dispose();
        
    }//GEN-LAST:event_btnBackActionPerformed
    
    private void clear(){
        if (tbl.getRowCount() > 0) {
            for (int i = tbl.getRowCount()-1; i>-1;i--) {
                model.removeRow(i);
                
            }
        }
    }
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(WholeDetails.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(WholeDetails.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(WholeDetails.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(WholeDetails.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new WholeDetails().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnBack;
    private javax.swing.JButton btnClear;
    private javax.swing.JButton btnDisplay;
    private javax.swing.JButton btnExit;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable tbl;
    private javax.swing.JTextField tbxMealRate;
    private javax.swing.JTextField tbxRemainingCash;
    private javax.swing.JTextField tbxTotalBalance;
    private javax.swing.JTextField tbxTotalShopping;
    // End of variables declaration//GEN-END:variables
}
