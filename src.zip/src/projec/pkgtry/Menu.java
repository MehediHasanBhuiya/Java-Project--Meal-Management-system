
package projec.pkgtry;

public class Menu extends javax.swing.JFrame {

  
    public Menu() {
        initComponents();
    }

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jButton4 = new javax.swing.JButton();
        btnDetails1 = new javax.swing.JButton();
        btnDetails = new javax.swing.JButton();
        btnShopEntry = new javax.swing.JButton();
        btnMealEntry = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(51, 51, 255));
        setMaximumSize(new java.awt.Dimension(1040, 700));
        setMinimumSize(new java.awt.Dimension(1040, 700));
        setPreferredSize(new java.awt.Dimension(1040, 700));
        getContentPane().setLayout(null);

        jLabel1.setBackground(new java.awt.Color(51, 51, 255));
        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 36)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("MENU");
        jLabel1.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        getContentPane().add(jLabel1);
        jLabel1.setBounds(330, 40, 410, 139);

        jLabel5.setBackground(new java.awt.Color(51, 51, 51));
        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 16)); // NOI18N
        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel5.setText("Meal Entry");
        getContentPane().add(jLabel5);
        jLabel5.setBounds(330, 210, 167, 38);

        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 16)); // NOI18N
        jLabel6.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel6.setText("Shop Entry");
        getContentPane().add(jLabel6);
        jLabel6.setBounds(330, 280, 167, 31);

        jLabel7.setFont(new java.awt.Font("Tahoma", 1, 16)); // NOI18N
        jLabel7.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel7.setText("Details");
        getContentPane().add(jLabel7);
        jLabel7.setBounds(320, 340, 167, 35);

        jLabel9.setFont(new java.awt.Font("Tahoma", 1, 16)); // NOI18N
        jLabel9.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel9.setText("Password Change");
        getContentPane().add(jLabel9);
        jLabel9.setBounds(330, 410, 167, 35);

        jLabel8.setFont(new java.awt.Font("Tahoma", 1, 16)); // NOI18N
        jLabel8.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel8.setText("Exit");
        getContentPane().add(jLabel8);
        jLabel8.setBounds(330, 480, 167, 32);

        jButton4.setBackground(new java.awt.Color(0, 102, 255));
        jButton4.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jButton4.setText("Click");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton4);
        jButton4.setBounds(570, 490, 84, 25);

        btnDetails1.setBackground(new java.awt.Color(0, 102, 255));
        btnDetails1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btnDetails1.setText("Click");
        btnDetails1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDetails1ActionPerformed(evt);
            }
        });
        getContentPane().add(btnDetails1);
        btnDetails1.setBounds(570, 420, 84, 25);

        btnDetails.setBackground(new java.awt.Color(0, 102, 255));
        btnDetails.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btnDetails.setText("Click");
        btnDetails.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDetailsActionPerformed(evt);
            }
        });
        getContentPane().add(btnDetails);
        btnDetails.setBounds(570, 350, 84, 25);

        btnShopEntry.setBackground(new java.awt.Color(0, 102, 255));
        btnShopEntry.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btnShopEntry.setText("Click");
        btnShopEntry.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnShopEntryActionPerformed(evt);
            }
        });
        getContentPane().add(btnShopEntry);
        btnShopEntry.setBounds(570, 280, 84, 25);

        btnMealEntry.setBackground(new java.awt.Color(0, 102, 255));
        btnMealEntry.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btnMealEntry.setText("Click");
        btnMealEntry.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMealEntryActionPerformed(evt);
            }
        });
        getContentPane().add(btnMealEntry);
        btnMealEntry.setBounds(570, 220, 84, 25);

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/projec/pkgtry/premade_background_224_by_ashensorrow.jpg"))); // NOI18N
        getContentPane().add(jLabel2);
        jLabel2.setBounds(-6, -6, 1170, 790);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnMealEntryActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMealEntryActionPerformed
        // TODO add your handling code here:
        MealEntry mi = new MealEntry();
        mi.setVisible(true);
        dispose();
    }//GEN-LAST:event_btnMealEntryActionPerformed

    private void btnShopEntryActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnShopEntryActionPerformed
        // TODO add your handling code here:
        ShopEntryWindows se = new ShopEntryWindows();
        se.setVisible(true);
        dispose();
    }//GEN-LAST:event_btnShopEntryActionPerformed

    private void btnDetailsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDetailsActionPerformed
        // TODO add your handling code here:
        WholeDetails wd=new WholeDetails();
        wd.setVisible(true);
        dispose();
        
    }//GEN-LAST:event_btnDetailsActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        // TODO add your handling code here:
        System.exit(0);
       
    }//GEN-LAST:event_jButton4ActionPerformed

    private void btnDetails1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDetails1ActionPerformed
        PassWordChange objPassChange = new PassWordChange();
        objPassChange.setVisible(true);
        objPassChange.showUser();
        dispose();
    }//GEN-LAST:event_btnDetails1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Menu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Menu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Menu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Menu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Menu().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnDetails;
    private javax.swing.JButton btnDetails1;
    private javax.swing.JButton btnMealEntry;
    private javax.swing.JButton btnShopEntry;
    private javax.swing.JButton jButton4;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    // End of variables declaration//GEN-END:variables
}
