
package projec.pkgtry;

import java.io.File;
import java.util.Scanner;
import javax.swing.JOptionPane;


public class loging extends javax.swing.JFrame {
  String user = "SWE" ;
  String passWord = "DIU";
    public loging() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        jMenu2 = new javax.swing.JMenu();
        Loging = new java.awt.Label();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        tbx1 = new javax.swing.JTextField();
        tbxpass = new javax.swing.JPasswordField();
        jButton1 = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();

        jMenu1.setText("File");
        jMenuBar1.add(jMenu1);

        jMenu2.setText("Edit");
        jMenuBar1.add(jMenu2);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMaximumSize(new java.awt.Dimension(1040, 700));
        setMinimumSize(new java.awt.Dimension(1040, 700));
        getContentPane().setLayout(null);

        Loging.setAlignment(java.awt.Label.CENTER);
        Loging.setBackground(getBackground());
        Loging.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        Loging.setFont(new java.awt.Font("Dialog", 1, 36)); // NOI18N
        Loging.setText("Login");
        getContentPane().add(Loging);
        Loging.setBounds(720, 250, 180, 50);

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("User Name ");
        getContentPane().add(jLabel1);
        jLabel1.setBounds(567, 352, 111, 36);

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("Password");
        getContentPane().add(jLabel2);
        jLabel2.setBounds(567, 409, 111, 36);

        tbx1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tbx1ActionPerformed(evt);
            }
        });
        getContentPane().add(tbx1);
        tbx1.setBounds(739, 355, 141, 36);

        tbxpass.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tbxpassActionPerformed(evt);
            }
        });
        getContentPane().add(tbxpass);
        tbxpass.setBounds(739, 412, 141, 33);

        jButton1.setText("Enter");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1);
        jButton1.setBounds(770, 500, 70, 23);

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/projec/pkgtry/Loging.gif"))); // NOI18N
        jLabel3.setMaximumSize(new java.awt.Dimension(1040, 722));
        jLabel3.setMinimumSize(new java.awt.Dimension(1040, 722));
        jLabel3.setPreferredSize(new java.awt.Dimension(1040, 722));
        getContentPane().add(jLabel3);
        jLabel3.setBounds(0, 0, 1050, 670);

        getAccessibleContext().setAccessibleDescription("");

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void tbxpassActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tbxpassActionPerformed
        
    }//GEN-LAST:event_tbxpassActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
         user = tbx1.getText();
         passWord = tbxpass.getText();
         String fUser = "0000" ;
         String fPassword= "0000";
         String valu;
         
         try { 
             File f = new File("loging.txt");
             Scanner scan = new Scanner(f);           
             while(scan.hasNext()){
               fUser = scan.next();
               fPassword = scan.next();
               
               if (user.equalsIgnoreCase(fUser)){
                   break;
               }
               
             }
            
        } 
         catch (Exception e) {
              JOptionPane.showMessageDialog(null, "File not Found");
        }
         
         if (user.equalsIgnoreCase(fUser) && passWord.equalsIgnoreCase(fPassword)){
             //JOptionPane.showMessageDialog(null, "You can Successfully login");
             Menu objMainMenu = new Menu ();
             objMainMenu.setVisible(true);
             dispose();
         }
         
         else if (user.equalsIgnoreCase(fUser)){
             JOptionPane.showMessageDialog(null, "Wrong PassWord");
         }
         
         else if (user.equalsIgnoreCase("SWE") && passWord.equalsIgnoreCase("Diu")){
                   Menu objMainMenu = new Menu ();
                   objMainMenu.setVisible(true);
                   dispose();
         }
         else {
           JOptionPane.showMessageDialog(null, "Uers not Found");
       }
         tbx1.setText("");
         tbxpass.setText("");

    }//GEN-LAST:event_jButton1ActionPerformed

    private void tbx1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tbx1ActionPerformed
        
    }//GEN-LAST:event_tbx1ActionPerformed

    
    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new loging().setVisible(true);
                //    
            }
        });
    }


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private java.awt.Label Loging;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JTextField tbx1;
    private javax.swing.JPasswordField tbxpass;
    // End of variables declaration//GEN-END:variables
}
