package projec.pkgtry;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

public class ShopEntryWindows extends javax.swing.JFrame {

    public ShopEntryWindows() {

        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTextField7 = new javax.swing.JTextField();
        jPopupMenu1 = new javax.swing.JPopupMenu();
        button1 = new java.awt.Button();
        btnMainMenu = new javax.swing.JButton();
        btnExit = new javax.swing.JButton();
        jPanel4 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jPanel5 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        cmbMoneyEntryName = new javax.swing.JComboBox<>();
        tbxMoneyEntry = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        btnMoneyEntry = new javax.swing.JButton();
        lbxMoney = new javax.swing.JLabel();
        btnMoneyClear = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        tbxCost = new javax.swing.JTextField();
        btnShopingCost = new javax.swing.JButton();
        jLabel11 = new javax.swing.JLabel();
        tbxDayNum = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        cmbShopEntryName = new javax.swing.JComboBox<>();
        btnShopingClear = new javax.swing.JButton();

        jTextField7.setBackground(new java.awt.Color(0, 0, 0));
        jTextField7.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jTextField7.setForeground(new java.awt.Color(204, 255, 51));
        jTextField7.setHorizontalAlignment(javax.swing.JTextField.CENTER);

        button1.setLabel("button1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(51, 51, 51));
        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        setFocusable(false);
        setMaximumSize(new java.awt.Dimension(1037, 650));
        setMinimumSize(new java.awt.Dimension(1037, 650));
        setPreferredSize(new java.awt.Dimension(1037, 650));
        getContentPane().setLayout(null);

        btnMainMenu.setBackground(new java.awt.Color(0, 102, 102));
        btnMainMenu.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btnMainMenu.setIcon(new javax.swing.ImageIcon(getClass().getResource("/projec/pkgtry/yellow-home-icon.png"))); // NOI18N
        btnMainMenu.setPreferredSize(new java.awt.Dimension(55, 55));
        btnMainMenu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMainMenuActionPerformed(evt);
            }
        });
        getContentPane().add(btnMainMenu);
        btnMainMenu.setBounds(120, 540, 55, 63);

        btnExit.setBackground(new java.awt.Color(153, 0, 0));
        btnExit.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btnExit.setIcon(new javax.swing.ImageIcon(getClass().getResource("/projec/pkgtry/Exit.jpg"))); // NOI18N
        btnExit.setPreferredSize(new java.awt.Dimension(55, 55));
        btnExit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnExitActionPerformed(evt);
            }
        });
        getContentPane().add(btnExit);
        btnExit.setBounds(240, 540, 55, 63);

        jPanel4.setBackground(new java.awt.Color(0, 153, 153));

        jLabel3.setFont(new java.awt.Font("Tahoma", 3, 40)); // NOI18N
        jLabel3.setText("Money Entry & Shop Entry");

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addContainerGap(91, Short.MAX_VALUE)
                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 596, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(73, 73, 73))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, 78, Short.MAX_VALUE)
                .addContainerGap())
        );

        getContentPane().add(jPanel4);
        jPanel4.setBounds(137, 5, 760, 100);

        jPanel5.setBackground(new java.awt.Color(0, 153, 153));

        jPanel3.setBackground(new java.awt.Color(0, 153, 153));
        jPanel3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel3.setForeground(new java.awt.Color(51, 51, 255));

        cmbMoneyEntryName.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        cmbMoneyEntryName.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "--Select name--", "Sheiblu", "Mehedi", "Maruf", "Shemul", "Sourove" }));
        cmbMoneyEntryName.setMinimumSize(new java.awt.Dimension(668, 571));
        cmbMoneyEntryName.setPreferredSize(new java.awt.Dimension(668, 570));
        cmbMoneyEntryName.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbMoneyEntryNameActionPerformed(evt);
            }
        });

        tbxMoneyEntry.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel1.setText("Money Entry");

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel2.setText("Name");

        btnMoneyEntry.setBackground(new java.awt.Color(255, 102, 0));
        btnMoneyEntry.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btnMoneyEntry.setText("Entry");
        btnMoneyEntry.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMoneyEntryActionPerformed(evt);
            }
        });

        lbxMoney.setBackground(new java.awt.Color(255, 51, 0));
        lbxMoney.setFont(new java.awt.Font("Tahoma", 0, 36)); // NOI18N
        lbxMoney.setForeground(new java.awt.Color(51, 51, 51));
        lbxMoney.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lbxMoney.setText("Money Entry");

        btnMoneyClear.setBackground(new java.awt.Color(255, 102, 0));
        btnMoneyClear.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btnMoneyClear.setText("Clear");
        btnMoneyClear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMoneyClearActionPerformed(evt);
            }
        });
        btnMoneyClear.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                btnMoneyClearKeyPressed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addComponent(lbxMoney, javax.swing.GroupLayout.PREFERRED_SIZE, 503, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(94, 94, 94)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(btnMoneyEntry, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(61, 61, 61)
                        .addComponent(btnMoneyClear, javax.swing.GroupLayout.PREFERRED_SIZE, 107, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 99, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(139, 139, 139)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(cmbMoneyEntryName, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tbxMoneyEntry, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addGap(32, 32, 32)
                .addComponent(lbxMoney, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(62, 62, 62)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cmbMoneyEntryName, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(40, 40, 40)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(tbxMoneyEntry, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 55, Short.MAX_VALUE)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnMoneyEntry, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnMoneyClear, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(50, 50, 50))
        );

        jPanel2.setBackground(new java.awt.Color(0, 153, 153));
        jPanel2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel2.setFocusCycleRoot(true);
        jPanel2.setPreferredSize(new java.awt.Dimension(850, 420));

        jLabel9.setBackground(new java.awt.Color(255, 0, 0));
        jLabel9.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel9.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel9.setText("Name : ");

        jLabel10.setBackground(new java.awt.Color(255, 0, 0));
        jLabel10.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel10.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel10.setText("Shoping Cost :");

        tbxCost.setBackground(new java.awt.Color(0, 0, 0));
        tbxCost.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        tbxCost.setForeground(new java.awt.Color(204, 255, 51));
        tbxCost.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        tbxCost.setText("0");

        btnShopingCost.setBackground(new java.awt.Color(255, 102, 0));
        btnShopingCost.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btnShopingCost.setText("Entry");
        btnShopingCost.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnShopingCostActionPerformed(evt);
            }
        });
        btnShopingCost.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                btnShopingCostKeyPressed(evt);
            }
        });

        jLabel11.setBackground(new java.awt.Color(255, 0, 0));
        jLabel11.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel11.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel11.setText("Day Num :");

        tbxDayNum.setBackground(new java.awt.Color(0, 0, 0));
        tbxDayNum.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        tbxDayNum.setForeground(new java.awt.Color(204, 255, 51));
        tbxDayNum.setHorizontalAlignment(javax.swing.JTextField.CENTER);

        jLabel4.setBackground(new java.awt.Color(255, 51, 0));
        jLabel4.setFont(new java.awt.Font("Tahoma", 0, 36)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(51, 51, 255));
        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel4.setText("Shoping Entry");

        cmbShopEntryName.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        cmbShopEntryName.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "--Select name--", "Sheiblu", "Mehedi", "Maruf", "Shemul", "Sourove" }));
        cmbShopEntryName.setMinimumSize(new java.awt.Dimension(668, 571));
        cmbShopEntryName.setPreferredSize(new java.awt.Dimension(668, 570));
        cmbShopEntryName.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbShopEntryNameActionPerformed(evt);
            }
        });

        btnShopingClear.setBackground(new java.awt.Color(255, 102, 0));
        btnShopingClear.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btnShopingClear.setText("Clear");
        btnShopingClear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnShopingClearActionPerformed(evt);
            }
        });
        btnShopingClear.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                btnShopingClearKeyPressed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGap(44, 44, 44)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 114, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 114, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jLabel11, javax.swing.GroupLayout.DEFAULT_SIZE, 135, Short.MAX_VALUE))
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(49, 49, 49)
                        .addComponent(cmbShopEntryName, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(tbxDayNum, javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(tbxCost, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 114, Short.MAX_VALUE)))
                .addGap(122, 122, 122))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 349, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(51, 51, 51))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addComponent(btnShopingCost, javax.swing.GroupLayout.PREFERRED_SIZE, 107, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(64, 64, 64)
                        .addComponent(btnShopingClear, javax.swing.GroupLayout.PREFERRED_SIZE, 107, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(99, 99, 99))))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(39, 39, 39)
                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 45, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cmbShopEntryName, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(36, 36, 36)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(tbxCost, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(30, 30, 30)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(tbxDayNum, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(52, 52, 52)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnShopingCost, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnShopingClear, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(46, 46, 46))
        );

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, 500, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, 487, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(33, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(140, 140, 140)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, 450, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(130, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel5);
        jPanel5.setBounds(0, -10, 1040, 720);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnMainMenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMainMenuActionPerformed
        Menu m=new Menu();
        m.setVisible(true);
        dispose();
    }//GEN-LAST:event_btnMainMenuActionPerformed

    private void btnExitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnExitActionPerformed
        System.exit(0);
    }//GEN-LAST:event_btnExitActionPerformed

    private void btnShopingCostActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnShopingCostActionPerformed
        try {
            String name;
            int taka = 0;
            int day;
            int totalTaka = 0;
            File f = new File("ShopingCost.txt");
            FileWriter fw = new FileWriter(f, true);
            name = cmbShopEntryName.getSelectedItem().toString();
            taka = Integer.parseInt(tbxCost.getText());
            day = Integer.parseInt(tbxDayNum.getText());
            fw.write(day + " " + name + " " + taka + " ");
            fw.close();

            JOptionPane.showMessageDialog(null, "Successfully Upload Data");

            File f2 = new File("TotalCost.txt");
            Scanner inputfile = new Scanner(f2);
            while (inputfile.hasNext()) {
            totalTaka = Integer.parseInt(inputfile.next());       
            }
            totalTaka += taka;
            FileWriter fw2 = new FileWriter(f2);
            String fileTotalCostIn = String.valueOf(totalTaka);

            fw2.write(fileTotalCostIn);
            fw2.close();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Sorry something Wrong");
        }

        tbxCost.setText("0");
//        tbxDayNum.setText("");
//        cmbShopEntryName.setSelectedIndex(0);
//
    }//GEN-LAST:event_btnShopingCostActionPerformed

    private void btnShopingCostKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_btnShopingCostKeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnShopingCostKeyPressed

    private void cmbMoneyEntryNameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbMoneyEntryNameActionPerformed
        // TODO add your handling code here:

    }//GEN-LAST:event_cmbMoneyEntryNameActionPerformed

    private void btnMoneyEntryActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMoneyEntryActionPerformed

        String name;
        int taka = 0;
        int totalMoney = 0;
        int ftaka = 0;
        String fname;

        name = cmbMoneyEntryName.getSelectedItem().toString();
        try{
        taka = Integer.parseInt(tbxMoneyEntry.getText());
        
          try {
            
             File f = new File("TotalPeopleGiveCost.txt");
             FileWriter fw = new FileWriter(f, true);
             Scanner inputfile = new Scanner(f);
              while (inputfile.hasNext()) {
                  fname = inputfile.next();
                  ftaka = inputfile.nextInt();
                     if (fname.equalsIgnoreCase(name)) {
                       totalMoney = ftaka;
                        }
                          }
                   totalMoney += taka;
                   fw.write(" " + name + " " + totalMoney);
                   fw.close();

                    } catch (Exception e) {
                     JOptionPane.showMessageDialog(null, "Sorry");
            }                
        
        } 
        catch(Exception e){
            JOptionPane.showMessageDialog(null, "Wrong Input");     
        }

//        try {
//            //taka = Integer.parseInt(tbxMoneyEntry.getText());
//            File f = new File("TotalPeopleGiveCost.txt");
//            FileWriter fw = new FileWriter(f, true);
//            Scanner inputfile = new Scanner(f);
//            while (inputfile.hasNext()) {
//                fname = inputfile.next();
//                ftaka = inputfile.nextInt();
//                if (fname.equalsIgnoreCase(name)) {
//                    totalMoney = ftaka;
//                }
//            }
//            totalMoney += taka;
//            fw.write(" " + name + " " + totalMoney);
//            fw.close();
//
//        } catch (Exception e) {
//            JOptionPane.showMessageDialog(null, "Sorry");
//        }
        
        totalRecivedTaka(taka);
    }//GEN-LAST:event_btnMoneyEntryActionPerformed

    private void cmbShopEntryNameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbShopEntryNameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cmbShopEntryNameActionPerformed

    private void btnShopingClearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnShopingClearActionPerformed
        tbxCost.setText("");
        tbxDayNum.setText("");
        cmbShopEntryName.setSelectedIndex(0);
    }//GEN-LAST:event_btnShopingClearActionPerformed

    private void btnShopingClearKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_btnShopingClearKeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnShopingClearKeyPressed

    private void btnMoneyClearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMoneyClearActionPerformed
       cmbMoneyEntryName.setSelectedIndex(0);
       tbxMoneyEntry.setText("");
    }//GEN-LAST:event_btnMoneyClearActionPerformed

    private void btnMoneyClearKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_btnMoneyClearKeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnMoneyClearKeyPressed
      
    public void totalRecivedTaka(int taka){
                 int totalTaka = 0;  
        try {
            File f = new File("TotalRecievedTaka.txt");
            Scanner scan = new Scanner(f);
            String stTotalTaka = scan.next();
            totalTaka = Integer.parseInt(stTotalTaka);
            FileWriter fw = new FileWriter(f);
            totalTaka += taka;
            fw.write(String.valueOf(totalTaka));
            fw.close();
            cmbMoneyEntryName.setSelectedIndex(0);
            tbxMoneyEntry.setText("");
           
        } 
        catch (Exception e) {
           JOptionPane.showMessageDialog(null,"Sorry Total Match Doesn't Work");
        }
        
        
    }
    
    
    
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ShopEntryWindows.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ShopEntryWindows.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ShopEntryWindows.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ShopEntryWindows.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ShopEntryWindows().setVisible(true);

            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnExit;
    private javax.swing.JButton btnMainMenu;
    private javax.swing.JButton btnMoneyClear;
    private javax.swing.JButton btnMoneyEntry;
    private javax.swing.JButton btnShopingClear;
    private javax.swing.JButton btnShopingCost;
    private java.awt.Button button1;
    private javax.swing.JComboBox<String> cmbMoneyEntryName;
    private javax.swing.JComboBox<String> cmbShopEntryName;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPopupMenu jPopupMenu1;
    private javax.swing.JTextField jTextField7;
    private javax.swing.JLabel lbxMoney;
    private javax.swing.JTextField tbxCost;
    private javax.swing.JTextField tbxDayNum;
    private javax.swing.JTextField tbxMoneyEntry;
    // End of variables declaration//GEN-END:variables
}
